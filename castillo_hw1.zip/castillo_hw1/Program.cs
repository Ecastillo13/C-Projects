﻿using System;

// Eli Castillo
// .NET Programming
// This program will calculate and display the payroll information of the user's input.

namespace payRoll
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Print 'welcome banner'
            Console.WriteLine("*******************************");
            Console.WriteLine("*     PAYCHECK CALCULATOR     *");
            Console.WriteLine("*******************************");
            Console.WriteLine("");

            // Ask user for values and store them in variables
            string name;
            double hoursWorked;
            double hourlyPayRate;
            Console.Write("Enter your name: ");
            name = Console.ReadLine();
            Console.Write("Enter your hours worked: ");
            hoursWorked = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter your hourly pay rate: ");
            hourlyPayRate = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("");

            // calculate and display table
            double grossPay = hourlyPayRate * hoursWorked;
            double taxes = grossPay * .2;
            double netPay = grossPay - taxes;
            Console.WriteLine("Your pay summary:");
            Console.WriteLine("----------------------------");
            Console.WriteLine("{0,-15} {1,10}", "Name:", name);
            Console.WriteLine("{0,-15} {1,10}", "Gross Pay:", grossPay.ToString("$0.00"));
            Console.WriteLine("{0,-15} {1,10}", "Taxes:", taxes.ToString("$0.00"));
            Console.WriteLine("{0,-15} {1,10}", "Net Pay:", netPay.ToString("$0.00"));
            Console.WriteLine("----------------------------");

        }
    }
}
