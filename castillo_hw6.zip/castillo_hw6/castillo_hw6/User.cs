﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace castillo_hw6
{
    public class User
    {
        private string name;
        private string email;
        private string placeOfOrigin;
        private string originDescription;
        private int gender; // 0 = male, 1 = female
        private int karma; // 0 = Hero, 1 = Villain
        private string personality;
        private string superPower;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Email
        {
            get { return email; }
            set
            {
                if (value.IndexOf("@") == -1)
                {
                    email = "Format is as follows: your@email.com";
                }
                else
                {
                    email = value;
                }
            }
        }

        public string PlaceOfOrigin
        {
            get { return placeOfOrigin; }
            set { placeOfOrigin = value; }
        }

        public string OriginDescription
        {
            get { return originDescription; }
            set { originDescription = value; }
        }

        public int Gender
        {
            get { return gender; }
            set
            {
                if (value < 0 || value > 1)
                {
                    gender = 0;
                }
                else
                {
                    gender = value;
                }
            }
        }

        public int Karma
        {
            get { return karma; }
            set
            {
                if (value < 0 || value > 1)
                {
                    karma = 0; // Hero
                }
                else
                {
                    karma = value; // villain
                }
            }
        }

        public string Personality
        {
            get { return personality; }
            set { personality = value; }
        }

        public string SuperPower
        {
            get { return superPower; }
            set { superPower = value; }
        }

        // default constructor
        public User()
        {
            Name = "";
            Email = "";
            PlaceOfOrigin = "";
            OriginDescription = "";
            Gender = 0;
            Karma = 0;
            Personality = "";
            SuperPower = "";
        }

        // non-default constructor
        public User(string name, string email, string placeOfOrigin,
            string originDescription, int gender, int karma,
            string personality, string superPower)
        {
            Name = name;
            Email = email;
            PlaceOfOrigin = placeOfOrigin;
            OriginDescription = originDescription;
            Gender = gender;
            Karma = karma;
            Personality = personality;
            SuperPower = superPower;
        }

        // Converting Gender int val to readable string
        public string GenderString()
        {
            if (Gender == 0)
            {
                return "Male";
            }
            else
            {
                return "Female";
            }
        }

        // Converting Karma val to readable string
        public string KarmaString()
        {
            if (Karma == 0)
            {
                return "Hero";
            }
            else
            {
                return "Villain";
            }
        }

        // ToString Function
        public override string ToString()
        {
            return String.Format("Name = {0}\nEmail = {1}\nPlace of Origin = {2}\n" +
                "Origin Story = {3}\nGender = {4}\nKarma = {5}\n" + 
                "Personality = {6}\nSuper Power = {7}\n"
                , Name, Email, PlaceOfOrigin , OriginDescription, 
                GenderString(), KarmaString(), Personality, SuperPower);
        }
    }
}
