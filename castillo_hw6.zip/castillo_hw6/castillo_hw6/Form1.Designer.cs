﻿namespace castillo_hw6
{
    partial class frmSuperHeroEntry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSuperHeroEntry));
            this.gbHeroInfo = new System.Windows.Forms.GroupBox();
            this.lblPersonality = new System.Windows.Forms.Label();
            this.comboBxPersonality = new System.Windows.Forms.ComboBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.listCities = new System.Windows.Forms.ListBox();
            this.lblPlaceOfOrigin = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.pBoxSuper = new System.Windows.Forms.PictureBox();
            this.lblGender = new System.Windows.Forms.Label();
            this.rbMale = new System.Windows.Forms.RadioButton();
            this.rbFemale = new System.Windows.Forms.RadioButton();
            this.gbHeroAttributes = new System.Windows.Forms.GroupBox();
            this.listPowers = new System.Windows.Forms.ListBox();
            this.lblPowers = new System.Windows.Forms.Label();
            this.lblHeroVillain = new System.Windows.Forms.Label();
            this.chkbHero = new System.Windows.Forms.CheckBox();
            this.gbKarma = new System.Windows.Forms.GroupBox();
            this.chkbVillain = new System.Windows.Forms.CheckBox();
            this.buttonRegister = new System.Windows.Forms.Button();
            this.gbOriginStory = new System.Windows.Forms.GroupBox();
            this.ddHeroes = new System.Windows.Forms.ComboBox();
            this.lblHeroes = new System.Windows.Forms.Label();
            this.richTxtOrigin = new System.Windows.Forms.RichTextBox();
            this.gbHeroInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxSuper)).BeginInit();
            this.gbHeroAttributes.SuspendLayout();
            this.gbKarma.SuspendLayout();
            this.gbOriginStory.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbHeroInfo
            // 
            this.gbHeroInfo.Controls.Add(this.lblPersonality);
            this.gbHeroInfo.Controls.Add(this.comboBxPersonality);
            this.gbHeroInfo.Controls.Add(this.txtEmail);
            this.gbHeroInfo.Controls.Add(this.lblEmail);
            this.gbHeroInfo.Controls.Add(this.listCities);
            this.gbHeroInfo.Controls.Add(this.lblPlaceOfOrigin);
            this.gbHeroInfo.Controls.Add(this.txtName);
            this.gbHeroInfo.Controls.Add(this.lblName);
            this.gbHeroInfo.Location = new System.Drawing.Point(12, 12);
            this.gbHeroInfo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbHeroInfo.Name = "gbHeroInfo";
            this.gbHeroInfo.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbHeroInfo.Size = new System.Drawing.Size(507, 198);
            this.gbHeroInfo.TabIndex = 0;
            this.gbHeroInfo.TabStop = false;
            this.gbHeroInfo.Text = "Hero Info";
            // 
            // lblPersonality
            // 
            this.lblPersonality.AutoSize = true;
            this.lblPersonality.Location = new System.Drawing.Point(9, 134);
            this.lblPersonality.Name = "lblPersonality";
            this.lblPersonality.Size = new System.Drawing.Size(77, 16);
            this.lblPersonality.TabIndex = 10;
            this.lblPersonality.Text = "Personality:";
            // 
            // comboBxPersonality
            // 
            this.comboBxPersonality.FormattingEnabled = true;
            this.comboBxPersonality.Items.AddRange(new object[] {
            "Jolly",
            "Serious",
            "Pure-Hearted",
            "Angry",
            "Confused",
            "Insecure",
            "Confident",
            "Hopeful",
            "Indifferent",
            "Evil",
            "Average"});
            this.comboBxPersonality.Location = new System.Drawing.Point(95, 134);
            this.comboBxPersonality.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBxPersonality.Name = "comboBxPersonality";
            this.comboBxPersonality.Size = new System.Drawing.Size(121, 24);
            this.comboBxPersonality.TabIndex = 9;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(59, 82);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(157, 22);
            this.txtEmail.TabIndex = 5;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(9, 82);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(44, 16);
            this.lblEmail.TabIndex = 4;
            this.lblEmail.Text = "Email:";
            // 
            // listCities
            // 
            this.listCities.FormattingEnabled = true;
            this.listCities.ItemHeight = 16;
            this.listCities.Items.AddRange(new object[] {
            "Gotham City",
            "New York",
            "Detroit",
            "Chicago",
            "San Diego",
            "Los Angeles",
            "Phoenix",
            "Dallas"});
            this.listCities.Location = new System.Drawing.Point(340, 34);
            this.listCities.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.listCities.Name = "listCities";
            this.listCities.Size = new System.Drawing.Size(120, 116);
            this.listCities.TabIndex = 3;
            // 
            // lblPlaceOfOrigin
            // 
            this.lblPlaceOfOrigin.AutoSize = true;
            this.lblPlaceOfOrigin.Location = new System.Drawing.Point(215, 38);
            this.lblPlaceOfOrigin.Name = "lblPlaceOfOrigin";
            this.lblPlaceOfOrigin.Size = new System.Drawing.Size(97, 16);
            this.lblPlaceOfOrigin.TabIndex = 2;
            this.lblPlaceOfOrigin.Text = "Place of Origin:";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(59, 34);
            this.txtName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(100, 22);
            this.txtName.TabIndex = 1;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(5, 34);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(47, 16);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Name:";
            // 
            // pBoxSuper
            // 
            this.pBoxSuper.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pBoxSuper.BackgroundImage")));
            this.pBoxSuper.Location = new System.Drawing.Point(611, 11);
            this.pBoxSuper.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pBoxSuper.Name = "pBoxSuper";
            this.pBoxSuper.Size = new System.Drawing.Size(216, 198);
            this.pBoxSuper.TabIndex = 1;
            this.pBoxSuper.TabStop = false;
            this.pBoxSuper.Click += new System.EventHandler(this.pBoxSuper_Click);
            // 
            // lblGender
            // 
            this.lblGender.AutoSize = true;
            this.lblGender.Location = new System.Drawing.Point(13, 30);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(55, 16);
            this.lblGender.TabIndex = 4;
            this.lblGender.Text = "Gender:";
            // 
            // rbMale
            // 
            this.rbMale.AutoSize = true;
            this.rbMale.Location = new System.Drawing.Point(81, 30);
            this.rbMale.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rbMale.Name = "rbMale";
            this.rbMale.Size = new System.Drawing.Size(58, 20);
            this.rbMale.TabIndex = 5;
            this.rbMale.TabStop = true;
            this.rbMale.Text = "Male";
            this.rbMale.UseVisualStyleBackColor = true;
            // 
            // rbFemale
            // 
            this.rbFemale.AutoSize = true;
            this.rbFemale.Location = new System.Drawing.Point(81, 57);
            this.rbFemale.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rbFemale.Name = "rbFemale";
            this.rbFemale.Size = new System.Drawing.Size(74, 20);
            this.rbFemale.TabIndex = 6;
            this.rbFemale.TabStop = true;
            this.rbFemale.Text = "Female";
            this.rbFemale.UseVisualStyleBackColor = true;
            // 
            // gbHeroAttributes
            // 
            this.gbHeroAttributes.Controls.Add(this.listPowers);
            this.gbHeroAttributes.Controls.Add(this.lblPowers);
            this.gbHeroAttributes.Controls.Add(this.rbMale);
            this.gbHeroAttributes.Controls.Add(this.rbFemale);
            this.gbHeroAttributes.Controls.Add(this.lblGender);
            this.gbHeroAttributes.Location = new System.Drawing.Point(12, 226);
            this.gbHeroAttributes.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbHeroAttributes.Name = "gbHeroAttributes";
            this.gbHeroAttributes.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbHeroAttributes.Size = new System.Drawing.Size(289, 274);
            this.gbHeroAttributes.TabIndex = 7;
            this.gbHeroAttributes.TabStop = false;
            this.gbHeroAttributes.Text = "Hero Physical Attributes:";
            // 
            // listPowers
            // 
            this.listPowers.FormattingEnabled = true;
            this.listPowers.ItemHeight = 16;
            this.listPowers.Items.AddRange(new object[] {
            "Flight",
            "Laser Vision",
            "Ice Breath",
            "Telekinesis",
            "Electricity",
            "Super Strength",
            "Super Speed",
            "Elasticity",
            "Super Genius",
            "Super Regeneration",
            "Super Reflexes",
            "Flame Power",
            "Freeze Time"});
            this.listPowers.Location = new System.Drawing.Point(107, 107);
            this.listPowers.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.listPowers.Name = "listPowers";
            this.listPowers.Size = new System.Drawing.Size(159, 148);
            this.listPowers.TabIndex = 8;
            // 
            // lblPowers
            // 
            this.lblPowers.AutoSize = true;
            this.lblPowers.Location = new System.Drawing.Point(5, 107);
            this.lblPowers.Name = "lblPowers";
            this.lblPowers.Size = new System.Drawing.Size(87, 16);
            this.lblPowers.TabIndex = 7;
            this.lblPowers.Text = "Super Power:";
            // 
            // lblHeroVillain
            // 
            this.lblHeroVillain.AutoSize = true;
            this.lblHeroVillain.Location = new System.Drawing.Point(3, 41);
            this.lblHeroVillain.Name = "lblHeroVillain";
            this.lblHeroVillain.Size = new System.Drawing.Size(80, 16);
            this.lblHeroVillain.TabIndex = 6;
            this.lblHeroVillain.Text = "Hero/Villain:";
            // 
            // chkbHero
            // 
            this.chkbHero.AutoSize = true;
            this.chkbHero.Location = new System.Drawing.Point(105, 41);
            this.chkbHero.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.chkbHero.Name = "chkbHero";
            this.chkbHero.Size = new System.Drawing.Size(59, 20);
            this.chkbHero.TabIndex = 7;
            this.chkbHero.Text = "Hero";
            this.chkbHero.UseVisualStyleBackColor = true;
            // 
            // gbKarma
            // 
            this.gbKarma.Controls.Add(this.chkbVillain);
            this.gbKarma.Controls.Add(this.chkbHero);
            this.gbKarma.Controls.Add(this.lblHeroVillain);
            this.gbKarma.Location = new System.Drawing.Point(319, 256);
            this.gbKarma.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbKarma.Name = "gbKarma";
            this.gbKarma.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbKarma.Size = new System.Drawing.Size(221, 100);
            this.gbKarma.TabIndex = 8;
            this.gbKarma.TabStop = false;
            this.gbKarma.Text = "Karma:";
            // 
            // chkbVillain
            // 
            this.chkbVillain.AutoSize = true;
            this.chkbVillain.Location = new System.Drawing.Point(105, 68);
            this.chkbVillain.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.chkbVillain.Name = "chkbVillain";
            this.chkbVillain.Size = new System.Drawing.Size(65, 20);
            this.chkbVillain.TabIndex = 8;
            this.chkbVillain.Text = "Villain";
            this.chkbVillain.UseVisualStyleBackColor = true;
            // 
            // buttonRegister
            // 
            this.buttonRegister.Location = new System.Drawing.Point(372, 386);
            this.buttonRegister.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonRegister.Name = "buttonRegister";
            this.buttonRegister.Size = new System.Drawing.Size(100, 28);
            this.buttonRegister.TabIndex = 9;
            this.buttonRegister.Text = "Register";
            this.buttonRegister.UseVisualStyleBackColor = true;
            this.buttonRegister.Click += new System.EventHandler(this.buttonRegister_Click);
            // 
            // gbOriginStory
            // 
            this.gbOriginStory.Controls.Add(this.ddHeroes);
            this.gbOriginStory.Controls.Add(this.lblHeroes);
            this.gbOriginStory.Controls.Add(this.richTxtOrigin);
            this.gbOriginStory.Location = new System.Drawing.Point(557, 226);
            this.gbOriginStory.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbOriginStory.Name = "gbOriginStory";
            this.gbOriginStory.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbOriginStory.Size = new System.Drawing.Size(355, 256);
            this.gbOriginStory.TabIndex = 10;
            this.gbOriginStory.TabStop = false;
            this.gbOriginStory.Text = "Origin Story:";
            // 
            // ddHeroes
            // 
            this.ddHeroes.FormattingEnabled = true;
            this.ddHeroes.Location = new System.Drawing.Point(85, 175);
            this.ddHeroes.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ddHeroes.Name = "ddHeroes";
            this.ddHeroes.Size = new System.Drawing.Size(160, 24);
            this.ddHeroes.TabIndex = 2;
            this.ddHeroes.SelectedIndexChanged += new System.EventHandler(this.ddHeroes_SelectedIndexChanged);
            // 
            // lblHeroes
            // 
            this.lblHeroes.AutoSize = true;
            this.lblHeroes.Location = new System.Drawing.Point(9, 175);
            this.lblHeroes.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHeroes.Name = "lblHeroes";
            this.lblHeroes.Size = new System.Drawing.Size(55, 16);
            this.lblHeroes.TabIndex = 1;
            this.lblHeroes.Text = "Heroes:";
            // 
            // richTxtOrigin
            // 
            this.richTxtOrigin.Location = new System.Drawing.Point(8, 30);
            this.richTxtOrigin.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.richTxtOrigin.Name = "richTxtOrigin";
            this.richTxtOrigin.Size = new System.Drawing.Size(337, 99);
            this.richTxtOrigin.TabIndex = 0;
            this.richTxtOrigin.Text = "";
            // 
            // frmSuperHeroEntry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(917, 540);
            this.Controls.Add(this.gbOriginStory);
            this.Controls.Add(this.buttonRegister);
            this.Controls.Add(this.gbKarma);
            this.Controls.Add(this.gbHeroAttributes);
            this.Controls.Add(this.pBoxSuper);
            this.Controls.Add(this.gbHeroInfo);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmSuperHeroEntry";
            this.Text = "Superhero Entry";
            this.Click += new System.EventHandler(this.frmSuperHeroEntryEntry_Click);
            this.gbHeroInfo.ResumeLayout(false);
            this.gbHeroInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxSuper)).EndInit();
            this.gbHeroAttributes.ResumeLayout(false);
            this.gbHeroAttributes.PerformLayout();
            this.gbKarma.ResumeLayout(false);
            this.gbKarma.PerformLayout();
            this.gbOriginStory.ResumeLayout(false);
            this.gbOriginStory.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbHeroInfo;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.ListBox listCities;
        private System.Windows.Forms.Label lblPlaceOfOrigin;
        private System.Windows.Forms.PictureBox pBoxSuper;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.RadioButton rbMale;
        private System.Windows.Forms.RadioButton rbFemale;
        private System.Windows.Forms.GroupBox gbHeroAttributes;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.ListBox listPowers;
        private System.Windows.Forms.Label lblPowers;
        private System.Windows.Forms.Label lblHeroVillain;
        private System.Windows.Forms.CheckBox chkbHero;
        private System.Windows.Forms.GroupBox gbKarma;
        private System.Windows.Forms.CheckBox chkbVillain;
        private System.Windows.Forms.Label lblPersonality;
        private System.Windows.Forms.ComboBox comboBxPersonality;
        private System.Windows.Forms.Button buttonRegister;
        private System.Windows.Forms.GroupBox gbOriginStory;
        private System.Windows.Forms.RichTextBox richTxtOrigin;
        private System.Windows.Forms.ComboBox ddHeroes;
        private System.Windows.Forms.Label lblHeroes;
    }
}

