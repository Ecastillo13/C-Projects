﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace castillo_hw6
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // create new list and controller
            List<User> users = new List<User>();
            UserController controller = new UserController(users);

            Application.Run(new frmSuperHeroEntry(controller));
        }
    }
}
