﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace castillo_hw6
{
    public partial class frmSuperHeroEntry : Form
    {

        private UserController controller;

        public frmSuperHeroEntry(UserController controller)
        {
            InitializeComponent();
            this.controller = controller;
            loadUsersDropDown();
        }

        private void buttonRegister_Click(object sender, EventArgs e)
        {
            // initialize variables for user selections
            string name = txtName.Text;
            string email = txtEmail.Text;
            string placeOfOrigin = listCities.GetItemText(listCities.SelectedItem);
            string originDescription = richTxtOrigin.Text;
            int gender;
            int karma;
            string personality = comboBxPersonality.GetItemText(comboBxPersonality.SelectedItem);
            string superPower = listPowers.GetItemText(listPowers.SelectedItem);

            // for gender check
            if (rbMale.Checked)
            {
                gender = 0; // male
            }
            else
            {
                gender = 1; // female
            }

            // for karma check
            if (chkbHero.Checked)
            {
                karma = 0; // Hero
            }
            else
            {
                karma = 1; // Villain
            }

            // add user to list in user controller
            controller.addUser(name, email, placeOfOrigin, originDescription,
                gender, karma, personality, superPower);

            loadUsersDropDown();
            selectSpecificUserDD(name);

            // output users registered
            MessageBox.Show(controller.OutputUsersAsString());
        }

        private void pBoxSuper_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You clicked Omni-Man!");
        }

        private void frmSuperHeroEntryEntry_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This is a Super Hero Registry Form!");
        }

        // load the users from the drop down menu
        public void loadUsersDropDown()
        {
            List<string> userNames = controller.attainUserNames();
            ddHeroes.DataSource = userNames;
            ddHeroes.Refresh();
        }

        // choose specific user from combo box
        private void selectSpecificUserDD(string name)
        {
            int index = ddHeroes.Items.IndexOf(name);
            ddHeroes.SelectedIndex = index;
        }

        private void ddHeroes_SelectedIndexChanged(object sender, EventArgs e)
        {
            string name;

            // define dictionary data type
            Dictionary<string, string> data;

            if (ddHeroes.SelectedIndex != -1)
            {
                name = ddHeroes.GetItemText(ddHeroes.SelectedItem);
                data = controller.attainDataForHeroByName(name);

                if (data != null)
                {
                    // store data for my variables
                    txtName.Text = data["name"];
                    txtEmail.Text = data["email"];
                    listCities.SelectedIndex = listCities.Items.IndexOf(data["place of origin"]);
                    richTxtOrigin.Text = data["origin description"];
                    if (data["gender"].Equals("0"))
                    {
                        rbMale.Checked = true;
                    }
                    else
                    {
                        rbFemale.Checked = true;
                    }
                    if (data["karma"].Equals("0"))
                    {
                        chkbHero.Checked = true;
                    }
                    else
                    {
                        chkbVillain.Checked = true;
                    }
                    comboBxPersonality.SelectedIndex = comboBxPersonality.Items.IndexOf(data["personality"]);
                    listPowers.SelectedIndex = listPowers.Items.IndexOf(data["super power"]);
                    Refresh();
                }
            }
            
            
        }
    }
}
