﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace castillo_hw6
{
    public class UserController
    {
        private List<User> users; // the list of users registered

        // default constructor
        public UserController()
        {
            users = null;
        }

        public UserController(List<User> users)
        {
            this.users = users;
        }

        // primary function of controller: add users
        public void addUser(string name, string email,
            string placeOfOrigin, string originDescription,
            int gender, int karma, string personality, string superPower)
        {
            User user = new User(name, email, placeOfOrigin,
                originDescription, gender, karma, personality,
                superPower);

            // add user to list
            users.Add(user);
        }

        // output users to screen each time button clicked
        public string OutputUsersAsString()
        {
            string result = "";
            foreach(User user in users)
            {
                result = result + user + "\n";
            }

            return result;

        }

        // attain hero names
        public List<string> attainUserNames()
        {
            List<string> result = new List<string>();
            foreach(User user in users)
            {
                result.Add(user.Name);
            }
            return result;
        }
        
        // get data from hero by name
        public Dictionary<string,string> attainDataForHeroByName(string name)
        {
            Dictionary<string,string> result = new Dictionary<string,string>();
            foreach(User user in users)
            {
                if (user.Name.Equals(name))
                {
                    result.Add("name", user.Name);
                    result.Add("email", user.Email);
                    result.Add("place of origin", user.PlaceOfOrigin);
                    result.Add("origin description", user.OriginDescription);
                    result.Add("gender", Convert.ToString(user.Gender));
                    result.Add("karma", Convert.ToString(user.Karma));
                    result.Add("personality", user.Personality);
                    result.Add("super power", user.SuperPower);
                    return result;
                }   
            }
            return null;
        }
    }
}
