﻿using System;
using System.IO;

// class Student
public class Student : Person
{
    // private data members
    private double gpa;
    private string major;
    private string yearInSchool;

    // expose private data members
    public double Gpa
    {
        get { return gpa; }
        set { gpa = value; }
    }

    public string Major
    {
        get { return major; }
        set { major = value; }
    }

    public string YearInSchool
    {
        get { return yearInSchool; }
        set
        {
            yearInSchool = value;
        }
    }

    // default constructor
    public Student()
    {
        gpa = 0;
        major = "";
        yearInSchool = "";
    }

    // non-default constructor
    public Student(string name, string address, int age, double gpa, string major, string yearInSchool)
    {
        Name = name;
        Address = address;
        Age = age;
        Gpa = gpa;
        Major = major;
        YearInSchool = yearInSchool;
    }

    // override getType() function replace with "student"
    public override string GetType()
    {
        return "Student";
    }

    // override ToString() function to add gpa, major, and yearInSchool
    public override string ToString()
    {
        return String.Format("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6:F2}", GetType(), Name, Address, Age, Major, YearInSchool, Gpa);

    }

    // override IsSuccessful() function to return "True" if GPA is over 2.0
    public override bool IsSuccessful()
    {
        if (Gpa > 2.0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}

