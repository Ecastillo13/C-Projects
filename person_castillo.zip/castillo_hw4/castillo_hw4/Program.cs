﻿using System;
using System.IO;

// main function
namespace advancedOO
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // define variables
            string Numresponse;
            string Name;
            string Address;
            int Age;
            string YearInSchool;
            string Major;
            double Gpa;
            int StartMile;
            int EndMile;
            double RunTimeSec;

            // create list of persons
            List<Person> listOfPersons = new List<Person>();

            // print out menu of options
            while (true)
            {
                Console.WriteLine("\nWhat type of person do you want to enter?\n" +
                                  "1. Student.\n" +
                                  "2. Runner.\n" +
                                  "3. Exit.\n");
                Console.Write("Enter the number of your choice: ");
                Numresponse = Console.ReadLine();

                // user typed '1' so student.
                if (Numresponse == "1")
                {
                    // ask relevant questions
                    Console.Write("\nEnter name: ");
                    Name = Console.ReadLine();
                    Console.Write("Enter address: ");
                    Address = Console.ReadLine();
                    Console.Write("Enter age: ");
                    Age = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Enter year in school: ");
                    YearInSchool = Console.ReadLine();
                    Console.Write("Enter major: ");
                    Major = Console.ReadLine();
                    Console.Write("Enter gpa: ");
                    Gpa = Convert.ToDouble(Console.ReadLine());
                    
                    // create new student object
                    Student student = new Student(Name, Address, Age, Gpa, Major, YearInSchool);

                    // add that student to the list
                    listOfPersons.Add(student); 
                }

                // user typed '2' so runner.
                if (Numresponse == "2")
                {
                    // ask relevant questions
                    Console.Write("Enter name: ");
                    Name = Console.ReadLine();
                    Console.Write("Enter address: ");
                    Address = Console.ReadLine();
                    Console.Write("Enter age: ");
                    Age = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Enter start location mile marker: ");
                    StartMile = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Enter end location mile marker: ");
                    EndMile = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Enter time in seconds: ");
                    RunTimeSec = Convert.ToDouble(Console.ReadLine());

                    // create new runner object
                    Runner runner = new Runner(Name, Address, Age, StartMile, EndMile, RunTimeSec);

                    // add that runner to the list
                    listOfPersons.Add(runner); 
                }

                // user typed '3' so print out tab-delimited format of all entries entered + print out successful names.
                if (Numresponse == "3")
                {
                    PrintWriter pw = new PrintWriter();
                    
                    // print out information in tab-delimited format
                    Console.WriteLine("\nHere is the data you entered in tab-delimited format: ");
                    pw.WritePersonsToScreen(listOfPersons);

                    // print out the successful ones + exit
                    Console.WriteLine("\nThese are the names of the successful ones: ");
                    foreach (Person person in listOfPersons)
                    {
                        if(person.IsSuccessful() == true)
                        {
                            Console.WriteLine("{0} ({1:F2})", person.Name, person.GetType());
                        }
                    }
                    break;
                }
            }
        }
    }
}
    
