﻿using System;
using System.IO;

// runner class
public class Runner : Person
{
    // private data members
    private double runTime;
    private int startMile;
    private int endMile;

    // expose private data members
    public double RunTime
    {
        get { return runTime; }
        set { runTime = value; }
    }
    public int StartMile
    {
        get { return startMile; }
        set { startMile = value; }
    }

    public int EndMile
    {
        get { return endMile; }
        set
        {
            endMile = value;
        }
    }

    // default constructor
    public Runner()
    {
        runTime = 0.0;
        startMile = 0;
        endMile = 0;
    }

    // non-default constructor
    public Runner(string name, string address, int age, int startMile, int endMile, double runTime)
    {
        Name = name;
        Address = address;
        Age = age;
        RunTime = runTime;
        StartMile = startMile;
        EndMile = endMile;
    }

    // override the GetType() function to return word "Runner"
    public override string GetType()
    {
        return "Runner";
    }

    // override ToString() method to display runner's info
    public override string ToString()
    {
        return String.Format("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}", GetType(), Name, Address, Age, StartMile, EndMile, RunTime);
    }

    // override the IsSuccessful() to return 'true' if runner's pace is less than 12 min per mile.
    public override bool IsSuccessful()
    {
        double runTimeInMin = RunTime / 60; // this gets you from # of seconds to minutes ran
        double milesRan = StartMile + EndMile;

        double pace = milesRan / runTimeInMin; // pace = minutes ran/miles ran

        if (pace < 12)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}
