﻿using System;
using System.IO;

interface Successful
{
    public bool IsSuccessful();
}

// class Person
public abstract class Person : Successful
{
    // declare private data members
    private string name;
    private int age;
    public string address;

    // expose private variables
    public string Name
    {
        get { return name; }
        set { name = value; }
    }

    public int Age
    {
        get { return age; }
        set { age = value; }
    }

    public string Address
    {
        get { return address; }
        set
        {
            address = value;
        }
    }

    // default constructor
    public Person()
    {
        name = "";
        age = 0;
        address = "";
    }

    // non-default constructor
    public Person(string name, int age, string address)
    {
        Name = name;
        Age = age;
        Address = address;
    }

    public override string ToString()
    {
        return String.Format("{0}\t{1}\t{2}\t{3}", GetType(), Name, Age, Address);
    }

    // is the person a student or a runner
    public abstract string GetType();

    // implement the IsSuccessful() function in 'Person'
    public abstract bool IsSuccessful();
}
