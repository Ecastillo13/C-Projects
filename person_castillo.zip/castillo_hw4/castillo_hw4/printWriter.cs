﻿using System;
using System.IO;

// define class 'PrintWriter'
public class PrintWriter
{
    // function takes in list[Person] and prints all entries in list to the screen using ToString() functions 
    // previously written.
    public void WritePersonsToScreen(List<Person> peeps)
    {
        foreach (object peep in peeps)
        {
            Console.WriteLine(peep.ToString());
        }
    }
}
